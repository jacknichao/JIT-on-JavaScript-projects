import numpy as np
import pandas as pd
import os

np.random.seed(seed=2) 
class_label = 'contains_bug'


def get_sample_rule(path: str, target_samples: int = 100):
    data = pd.read_csv(path)
    total_size = data.shape[0]
    target_samples = 100

    # the number of buggy commits
    positive_number = data[data['contains_bug']==True].shape[0]
    # the number of clean commits
    negative_number = data[data['contains_bug']==False].shape[0]
    target_positivate_number = int(np.floor(positive_number/total_size * target_samples))
    target_negative_number = int(target_samples - target_positivate_number)

    return {
        1: target_positivate_number,
        0: target_negative_number
    }



#  store sampled data
def store_sample_data(source_file_path: str, target_root_path: str):
    typicalNDict = get_sample_rule(source_file_path)
    def typicalsamling(group, typicalNDict):
        name = group.name
        n = typicalNDict[name]
        return group.sample(n=n)

    # sampled data
    result:pd.DataFrame = pd.read_csv(source_file_path).groupby('contains_bug').apply(typicalsamling, typicalNDict)
    # print(result['contains_bug'].value_counts())
    saved_features= ["commit_id","time_stamp","commit_message","contains_bug"]
    result[saved_features].sort_values(by='time_stamp', axis=0, ascending=False).to_csv( os.path.join(target_root_path, os.path.basename(source_file_path).split('.')[0]+"-sampled.csv"), index=False)



# path_to_origianl_data and path_to_saved_data
source_root_path = "jsproject-jshtml"
target_root_path = "manual-investigation"

for root, dirs, files in os.walk(source_root_path):
    for file in files:
        store_sample_data(os.path.join(root,file),target_root_path=target_root_path)
        print("Stroing {} finished!".format(file))
        

     
