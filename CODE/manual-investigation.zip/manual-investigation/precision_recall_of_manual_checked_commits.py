from sklearn import metrics
import os
import pandas as pd






projs = []
prec = []
rec = []

def eval_each_manualed_project(path:str):
    data = pd.read_csv(path)
    pred = data['contains_bug']
    manual = data['MANUAL_CHECK']
    precision = metrics.precision_score(manual,pred)
    recall = metrics.recall_score(manual,pred)
    name = os.path.basename(path)
    name = name[7:]
    print(name, "precison:%.3f"%precision,"recall:%.3f"%recall)
    projs.append(os.path.basename(path))
    prec.append(precision)
    rec.append(recall)

manual_path = "manual-investigation"

for root, dirs, files in os.walk(manual_path):
    for file in files:
        if "MANUAL" in file:
            # print(file)
            eval_each_manualed_project(os.path.join(root,file))

df = pd.DataFrame({
    'projects':projs,
    'precision':prec,
    'recall':rec
})


print("--"*20)
print("precision avg:", df['precision'].mean())
print("recall avg:", df['recall'].mean())

print("--"*20)
print("precision range: %.2f ---- %.2f"%(df['precision'].min(), df['precision'].max()))

print("--"*20)
print("recall range: %.2f ---- %.2f"%(df['recall'].min(), df['recall'].max()))