from sqlalchemy import Column, String, Integer, Float
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class TimeSeriesNonEffort(Base):
    """
    10 time series cross validation
    """
    __tablename__ = "MR1_jshtml_TimeSeriesNonEffrot"

    id = Column(Integer,primary_key= True,autoincrement= True)
    # project name
    pname = Column(String(64),nullable=False)
    # project tyep [oss-original,js]
    ptype = Column(String(64),nullable=False)
    # the classification model used
    model = Column(String(64),nullable=False)
    # the series index of cross-validation
    seriesindex = Column(Integer, nullable=False)

    # non-effort measures
    precision = Column(Float,nullable=False)
    recall = Column(Float,nullable=False)
    fmeasure = Column(Float,nullable=False)
    auc = Column(Float,nullable=False)
    ifa = Column(Float, nullable=False)
    pfa = Column(Float, nullable=False)

class TimeSeriesEffort(Base):
    """
    10 time series cross validation considering effort
    """
    __tablename__ = "MR1_jshtml_TimeSeriesEffrot"

    id = Column(Integer, primary_key=True, autoincrement=True)
    # project name
    pname = Column(String(64), nullable=False)
    ptype = Column(String(64), nullable=False)

    # the classification model used
    model = Column(String(64), nullable=False)

    # model type; indicate supervised or unsupervised
    modeltype = Column(String(64), nullable=False)
    # the series index of cross-validation
    seriesindex = Column(Integer, nullable=False)

    # effort measures
    precision20p = Column(Float, nullable=False)
    recall20p = Column(Float, nullable=False)
    fmeasure20p = Column(Float, nullable=False)
    pci20p = Column(Float, nullable=False)
    popt = Column(Float, nullable=False)
    ifa = Column(Float, nullable=False)
