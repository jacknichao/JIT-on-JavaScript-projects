import pandas as pd
from Models.effort import Effort
import sys,os
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"commons"))


class LT:
    """
    simple unsupervised method LT.(1/lt)
    """

    def predict(self,X_test:pd.DataFrame, y_test:pd.Series):
        """
        predict on test data and return two types of performance measures

        :param X_test: testing data
        :param y_test: label of testing data
        :return: all effort performance values
        """
        X_test = X_test.join(y_test)

        # add a small value on lt to avoid such a situation that division zero
        X_test['y_pred_prob'] = 1/(X_test['lt']+0.000001)

        X_test_sorted = X_test.sort_values(by='y_pred_prob',ascending=False)

        # get performance results
        effort = Effort(testFullData=X_test_sorted[['la','ld','contains_bug']])
        effort_values = effort.getAllMeasures()

        return effort_values
