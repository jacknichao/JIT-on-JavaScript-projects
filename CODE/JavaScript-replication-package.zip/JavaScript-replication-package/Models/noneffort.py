from sklearn import metrics
from typing import Dict

class NonEffort:

    def __init__(self,y_true,y_pred,y_pred_prob):
        """
        :param testData: the testing data
        :param y_true: the true label of the test data
        :param y_pred: the prediction of instance labels
        :param y_pred_prob: the possibility of defect-prone
        """
        self.y_true = y_true
        self.y_pred = y_pred
        self.y_pred_prob = y_pred_prob

    def getPrecision(self)->float:
        return metrics.precision_score(y_true=self.y_true,y_pred=self.y_pred)

    def getRecall(self)->float:
        return metrics.recall_score(y_true=self.y_true,y_pred=self.y_pred)

    def getFmeasure(self)->float:
        return metrics.f1_score(y_true=self.y_true,y_pred=self.y_pred)

    def getAUC(self)->float:

        return metrics.roc_auc_score(y_true=self.y_true,y_score=self.y_pred)

    def getPFA(self)->float:
        tn, fp, fn, tp =metrics.confusion_matrix(self.y_true,self.y_pred).ravel()
        if fp==0 and tn ==0:
            pfa = 0
        else:
            pfa = fp / (fp + tn)
        return pfa




    def getAllMeasures(self) -> Dict[str, float]:
        """
        calculate all non-effort aware performance measures
        :return: return all performance measure in a dictionary
        """
        return {
            "precision": self.getPrecision(),
            "recall": self.getRecall(),
            "fmeasure": self.getFmeasure(),
            "auc": self.getAUC(),
            "pfa": self.getPFA()
        }



