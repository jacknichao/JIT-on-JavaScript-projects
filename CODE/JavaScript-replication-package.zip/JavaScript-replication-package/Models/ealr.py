import pandas as pd
import numpy as np
from imblearn.under_sampling import RandomUnderSampler
from sklearn.linear_model import LinearRegression
from Models.effort import Effort
import sys,os
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"commons"))
from commons.Configs import AllConfigs

class EALR:
    """
    EALR proposed by Kamei et al.
    """

    def __init__(self):
        self.__features: list = AllConfigs.expsettings['featurename']
        self.__label: str = AllConfigs.expsettings['labelname']

    def fit(self,X:pd.DataFrame ,y:pd.Series):
        """
        build a prediction model
        :param X: training data
        :param y: training label
        :return:
        """
        undersample= RandomUnderSampler(random_state=1)
        X_resample, y_resample = undersample.fit_sample(X,y)
        X_resample: pd.DataFrame = pd.DataFrame(X_resample,columns=self.__features)
        y_resample: pd.Series = pd.Series(y_resample,name=self.__label)

        y_resample: pd.Series = y_resample / (X_resample['la']+X_resample['ld']+0.000001)

        log_features: list = self.__features.copy()
        log_features.remove('is_fix')

        X_resample_log = X_resample.loc[:,log_features].applymap(lambda data: np.log(data+1) if data > 0 else data)
        X_resample_log['is_fix'] = X_resample['is_fix']

        self.ealr = LinearRegression()
        self.ealr.fit(X_resample_log, y_resample)

    def predict(self,X_test:pd.DataFrame, y_test:pd.Series):
        """
        predict on test data and return two types of performance measures

        :param X_test: testing data
        :param y_test: label of testing data
        :return: all effort performance values
        """
        log_features: list = self.__features.copy()
        log_features.remove('is_fix')

        X_test_log = X_test.loc[:, log_features].applymap(lambda data: np.log(data+1) if data>0 else data)
        X_test_log['is_fix'] = X_test['is_fix']

        y_pred = self.ealr.predict(X_test_log)

        X_test['y_pred']= y_pred
        X_test['contains_bug'] = y_test

        X_test_sort = X_test.sort_values(by='y_pred',ascending=False)

        effort = Effort(testFullData=X_test_sort[['la','ld','contains_bug']])
        effort_values = effort.getAllMeasures()

        return effort_values
