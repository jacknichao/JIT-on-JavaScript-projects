import pandas as pd
import numpy as np
from effort import Effort
import time,sys,os
from sklearn.model_selection import TimeSeriesSplit
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"commons"))
from Configs import AllConfigs


class OneWay:
    """
    an supervised jit method proposed by Tim et al.
    """
    __features: list = AllConfigs.expsettings['featurename']
    __label: list = AllConfigs.expsettings['labelname']


    def fit(self, X: pd.DataFrame, y: pd.Series, featlist: list=__features):
        """
        predict on test data and return two types of performance measures

        :param X: traing data
        :param y: label of testing data
        :param featlist: a list containing all features
        """
        allfeatmeanvalues:list(tuple) = []

        for feat in featlist:
            effortvalue=self.getTrainPerformance(X,y,feat)
            allfeatmeanvalues.append(effortvalue)

        # sort by mean performance value in desc order
        allfeatmeanvalues_sorted= sorted(allfeatmeanvalues,key=lambda item: item[1], reverse=True)

        # get best feature
        self.bestfeatname = allfeatmeanvalues_sorted[0][0]

    def getTrainPerformance(self,X: pd.DataFrame, y: pd.Series, feat)->tuple:
        """
        :return: a tuple (feat, mean performance value)
        """

        # pre-processing
        # step 1: combine feature values and label values
        # X = X.join(y)
        X[self.__label]=y

        # step 2: sort in descending order based on specific feature
        X['prob']= 1/ (X[feat]+0.000001)
        X_sorted = X.sort_values(by='prob', ascending=False)

        # get performance results
        effort = Effort(testFullData=X_sorted[['la', 'ld', 'contains_bug']])
        effort_values = effort.getAllMeasures()

        return (feat,np.mean([effort_values['precision20p'],effort_values['recall20p'],
                effort_values['fmeasure20p'],effort_values['popt'],-effort_values['pci20p']]))


    def predict(self,X_test:pd.DataFrame, y_test:pd.Series)->dict:
        """
        predict on test data and return performance measures

        :param X_test: testing data
        :param y_test: label of testing data
        :return: all effort performance values
        """
        # step 1: combine feature values and label values
        X_test = X_test.join(y_test)

        # step 2: sort in ascending order based on specific feature, so that 1/ bestmetric will be sorted in desc order
        # print(self.bestfeatname)
        X_test['prob']= 1/ (X_test[self.bestfeatname]+0.000001)
        X_test_sorted = X_test.sort_values(by='prob', ascending=False)


        # get performance results
        effort = Effort(testFullData=X_test_sorted[['la','ld','contains_bug']])
        effort_values = effort.getAllMeasures()

        return effort_values
