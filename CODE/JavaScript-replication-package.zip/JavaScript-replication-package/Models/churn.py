import pandas as pd
from effort import Effort


class Churn:
    """
    unsupervised method proposed by liu et al.(la+ld)
    """


    def predict(self,X_test:pd.DataFrame, y_test:pd.Series):
        """
        predict on test data and return two types of performance measures

        :param X_test: testing data
        :param y_test: label of testing data
        :return: all effort performance values
        """
        # pre-processing
        # step 1: combine feature values and label values
        X_test = X_test.join(y_test)

        # step 2: calculate the risk value of each commit based on 1/(la+ld) features
        X_test['y_pred_prob'] =1/(X_test['la']+X_test['ld']+0.000001)

        # step 3: sort in descending order based on y_pred_prob
        X_test_sorted = X_test.sort_values(by='y_pred_prob',ascending=False)

        # get performance results
        effort = Effort(testFullData=X_test_sorted[['la','ld','contains_bug']])
        effort_values = effort.getAllMeasures()

        return  effort_values


