from sklearn.linear_model import LogisticRegression
from imblearn.under_sampling import RandomUnderSampler
import pandas as pd
from Models.effort import Effort
from Models.noneffort import NonEffort
import sys,os
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"commons"))
from commons.Configs import AllConfigs



class CBSP:
    """
    CBS+ proposed by Qiao Huang et al.
    """

    def __init__(self):
        self.__features: list = AllConfigs.expsettings['featurename']
        self.__label: str = AllConfigs.expsettings['labelname']

    def fit(self,X:pd.DataFrame ,y:pd.Series, usedFeatures:list):
        """
        build a prediction model
        :param X: training data
        :param y: training label
        :return:
        """
        sampler= RandomUnderSampler(random_state=1)
        X_resample, y_resample = sampler.fit_sample(X,y)
        # after resample, we need to re-constract X_resample,y _resample as dataframe
        X_resample:pd.DataFrame = pd.DataFrame(X_resample,columns=usedFeatures)
        y_resample:pd.Series = pd.Series(y_resample,name=self.__label)

        # build prediction model
        self.lr = LogisticRegression(solver='liblinear', max_iter=100)
        self.lr.fit(X_resample,y_resample)

    def predict(self, X_test: pd.DataFrame, y_test: pd.Series):
        y_pred = self.lr.predict(X_test)
        y_pred_prob_twodimension = self.lr.predict_proba(X_test)
        y_pred_prob = self.lr.predict_proba(X_test)[:, 1]

        # after prediction, we need to add y_pred and y_pred_prob into original dataframe
        X_test['y_pred'] = y_pred
        X_test['y_pred_prob'] = y_pred_prob
        X_test['locs'] = X_test['la'] + X_test['ld']
        X_test['ratio'] = y_pred_prob / (X_test['la'] + X_test['ld'] + 0.000001)
        X_test['contains_bug'] = y_test

        X_test_sorted = X_test.sort_values(by=['y_pred', 'ratio'], ascending=[False, False])

        # get performance results
        effort = Effort(testFullData=X_test_sorted[['la', 'ld', 'contains_bug']])

        ifa = NonEffort(y_true=y_test, y_pred=y_pred, y_pred_prob=y_pred_prob_twodimension).getIFA()
        effort_values = effort.getAllMeasures()
        effort_values['ifa'] = ifa

        return effort_values
