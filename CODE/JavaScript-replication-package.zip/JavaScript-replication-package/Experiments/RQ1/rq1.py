import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"commons"))
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"ORM"))
sys.path.append(os.path.join(os.path.dirname(__file__),os.path.pardir,"Models"))
import pandas
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
from commons.Configs import AllConfigs
from commons.mylogger import logger
from typing import Tuple
from Models.cbsp import CBSP
from Models.oneway import OneWay
from Models.ealr import EALR
from Models.lt import LT
from Models.churn import Churn
from ORM.db import DBOperator
from ORM.results import TimeSeriesEffort
from sqlalchemy.orm import Session


class RQ1:
    """
    in this class, we do all the experiment described in rq1.
    """
    # all jit feature set + js features
    __features: list = AllConfigs.expsettings['featurename']
    print(__features)
    # class label
    __label: str = AllConfigs.expsettings['labelname']

    def __init__(self, projectpath, projectname, projecttype, dbsession: Session):

        logger.info("current project: %s" % projectname)
        self.projectname = projectname
        self.projecttype = projecttype
        self.filepath: str = os.path.join(projectpath,projectname)
        self.dbsession = dbsession

    def __loadData(self, timeAware: bool = True) -> Tuple[pandas.core.frame.DataFrame, pandas.core.series.Series]:
        """
        load project data from csv files
        :param timeAware: indicate whether we should sort all commit in time series
        :return: a tuple containing training data X and corresponding label y
        """
        try:
            df: pandas.DataFrame = pandas.read_csv(self.filepath)
        except Exception as e:
            logger.error('read file %s error! msg: %s' % (self.filepath, e))


        if timeAware:
            # sort by time_stamp if we consider commit time
            df.sort_values('time_stamp', inplace=True)
            X = df[self.__features]
            y = df[self.__label].astype(np.int)
        else:
            # get data and label separate
            X = df[self.__features]
            # convert label to int
            y = df[self.__label].astype(np.int)
        return X, y


    def timeseriesCVResults(self, jitmodelDict: dict,jitmodelTypes:dict, n_splits: int=11, max_train_size=None) -> None:
        """
        calculate all performance measure according to the models stored in a dictionary
        Notes: this method takes time into consideration
        :param jitmodelDict: a dictionary, key: a short name for model, value: a classification model
        :param jitmodelTypes: a dictionary, key: a short name for model, value: model type [un]supervised
        :param n_splits: the number of time series split, the last split will be ignored
        :param max_train_size: the maximum number of folds be treated as training data
        :return:
        """
        tsSplit = TimeSeriesSplit(n_splits=n_splits, max_train_size=max_train_size)
        # load time series data
        X, y = self.__loadData(timeAware=True)

        # iterate each model
        for modelname, model in jitmodelDict.items():
            logger.info("type: %s, project: %s, classifier: %s TimeSeries" % (self.projecttype,self.projectname, modelname))

            seriesindex: int = 0
            for trainIndex, testIndex in tsSplit.split(X, y):
                seriesindex += 1
                # the last split should be ignore since the limitation of szz algorithm
                if seriesindex >10:
                    break
                logger.info("project: %s, classifier: %s[%s],cvIndex: %s." %
                             (self.projectname, modelname, jitmodelTypes[modelname], seriesindex))

                # supervised model should be fitted first
                if jitmodelTypes[modelname] == "supervised":
                    model.fit(X.loc[trainIndex,], np.ravel(y.loc[trainIndex,]))

                effortResult= model.predict(X.loc[testIndex,], y.loc[testIndex,])
                # print(noneffortResult)


                result= TimeSeriesEffort(pname=self.projectname,
                                         ptype=self.projecttype,
                                         model=modelname,
                                         modeltype= jitmodelTypes[modelname],
                                         seriesindex=seriesindex,

                                         precision20p=effortResult['precision20p'],
                                         recall20p=effortResult['recall20p'],
                                         fmeasure20p=effortResult['fmeasure20p'],
                                         pci20p=effortResult['pci20p'],
                                         popt=effortResult['popt'],
                                         ifa=effortResult['ifa']
                                         )

                self.dbsession.add(result)
                self.dbsession.commit()

            logger.info("project: %s, classifier: %s[%s], TimeSeries, finished!" %
                         (self.projectname, modelname,jitmodelTypes[modelname]))


if __name__ == "__main__":
    jitmodels: dict = {
        "cbsp": CBSP(),
        "oneway": OneWay(),
        "ealr": EALR(),
        "lt": LT(),
        "churn": Churn()
    }

    jitmodeltype:dict = {
        "cbsp": "supervised",
        "oneway": "supervised",
        "ealr": "supervised",
        "lt": "unsupervised",
        "churn": "unsupervised"
    }

    allfilespath = AllConfigs.expsettings['data_root_path']
    dbsession = DBOperator().getScopedSession()

    for root, dirs, files in os.walk(allfilespath):
        for file in files:
            if os.path.splitext(file)[1].endswith(".csv"):
                protype = "js"
                rq1 = RQ1(projectpath=root, projectname=file, projecttype=protype, dbsession=dbsession)
                rq1.timeseriesCVResults(jitmodelDict=jitmodels, jitmodelTypes=jitmodeltype, n_splits=11)

    dbsession.close()
    logger.info("RQ1 executed successfully!")














