library("pROC")
library("randomForest")
library("naivebayes")
library("reshape")
library("e1071")
library("ScottKnottESD")
library("caret")
library("pracma")
library("PRROC")


source("C://Rwork/JITalibaba/packages/measures.R")
source("C://Rwork/JITalibaba/packages/imbalance.R")
source("C://Rwork/JITalibaba/packages/CBS.R")
source("C://Rwork/JITalibaba/packages/VarImportance.R")
source("C://Rwork/JITalibaba/packages/one-way.R")

root_path <- "C://Study/szz_investigation/"
collinearity_fn <- paste(root_path, "collinearity.csv", sep="")
collinearity_features <- read.csv(collinearity_fn)
szz_labels <- c("buggy_B2", "buggy_AG", "buggy_MA", "buggy_RA")
szz_baseline <- "buggy_RA"

#"activemq", "camel", "derby", "geronimo", "hcommon", "hbase", "mahout", "openjpa", "pig", "tuscany"
projects <- c("openjpa", "pig", "tuscany")

bootstrap_times <- 1000
classifier <- "random_forest"


# whether computing importance
cal_importance <- TRUE

# "auc", "brier", "precision", "recall", "f1measure", "precision20", "recall20", "f1measure20", "IFA", "PCI20", "Popt", "oneway_p20", "oneway_r20", "oneway_f20", "oneway_popt"
calculated_measures <- c("auc", "auprc", "precision", "recall", "f1measure", "precision20", "recall20", "f1measure20", "Popt")
calculated_measures2 <- c("auc", "auprc", "precision", "recall", "f1measure", "precision20", "recall20", "f1measure20", "Popt")

store_result_to_frame<-function(result_frame, scores_vector){
	temp_frame <- data.frame(scores_vector)
	if (is.null(result_frame)){
		result_frame <- temp_frame
	}
	else {
		result_frame <- cbind(result_frame, temp_frame)
	}
	return(result_frame)
}


for (p in projects){
	# result preparation
	importance_rank_frame <- NULL

	filter_features <- as.vector(collinearity_features[p][,1])
	filter_features <- append(filter_features, szz_labels)

	fn <- paste(c(root_path, "data_csvs/", p, ".csv"), collapse="")
	fn2 <- paste(c(root_path, "data_csvs2/", p, ".csv"), collapse = "")
	print(paste("filename: ", fn, sep=""))
	data <- read.csv(fn)
	raw_data <- read.csv(fn2)

	data <- data[-which(raw_data$la+raw_data$ld > 10000 | raw_data$nf > 100), ]
	raw_data <- raw_data[-which(raw_data$la+raw_data$ld > 10000 | raw_data$nf > 100), ]

	var_names <- names(data)
	metrics <- var_names[!var_names %in% szz_labels]
	metrics <- metrics[!metrics %in% c("la", "ld")]

	var_names1 <- var_names[!var_names %in% filter_features]
	var_names_str <- paste(var_names1, collapse="+")
	print(var_names_str)
	print(szz_labels)

	for (szz_label in szz_labels){
		print(szz_label)
		result_frame <- NULL

		form <- as.formula(paste(szz_label, var_names_str, sep=" ~ "))
		var_names2 <- append(var_names1, szz_label)
		var_names2 <- append(var_names2, szz_baseline)

		temp_data <- data[var_names2]
		temp_data$real_la <- raw_data$la
		temp_data$real_ld <- raw_data$ld

		# result preparation
		auc_scores <- c()
		auprc_scores <- c()
		brierscores <- c()
		precision_scores <- c()
		recall_scores <- c()
		F1_scores <- c()
		precision20_scores <- c()
		recall20_scores <- c()
		F1_20_scores <- c()
		IFA_scores <- c()
		inspected_changes <- c()
		popt_values <- c()
		oneway_p20_scores <- c()
		oneway_r20_scores <- c()
		oneway_f20_scores <- c()
		oneway_popt_values <- c()
		importance_matrix <- NULL

		# factorise labels
		buggy_labels <- factor(temp_data[szz_label][,1], order=TRUE, levels=c("clean", "buggy"))
		temp_data[szz_label][,1] <- buggy_labels
		buggy_real_labels <- factor(temp_data[szz_baseline][,1], order=TRUE, levels=c("clean", "buggy"))
		temp_data[szz_baseline][,1] <- buggy_real_labels

		# start bootstrap runs
		for (i in 1:bootstrap_times){
			print(i)
			set.seed(i); train_indices <- sample(nrow(temp_data), replace=TRUE)
			train_data <- temp_data[train_indices,]
			test_data <- temp_data[-unique(train_indices),]

			# Undersampling
			# train_data <- undersampling(train_data, szz_label)
		

			# calculate the likelihood scores being "buggy" for changes in testing set
			if (classifier == "random_forest"){
				fit <- randomForest(form, train_data, ntree=100)
				prediction <- predict(fit, test_data, type="prob")
				prob <- prediction[,2]
				# compute importance values of features
				# imp <- data.frame(importance(fit, type=1))
				# if (is.null(importance_matrix)){
				# 	importance_matrix <- imp$MeanDecreaseGini
				# }
				# else {
				# 	importance_matrix <- rbind(importance_matrix, imp$MeanDecreaseGini)
				# }
			}
			if (classifier == "logistic_regression"){
				fit <- glm(form, train_data, family=binomial)
				prediction <- predict(fit, test_data, type="response")
				prob <- prediction
				# imp <- varImp(fit)
				# if (is.null(importance_matrix)){
				# 	importance_matrix <- imp$Overall
				# }
				# else {
				# 	importance_matrix <- rbind(importance_matrix, imp$Overall)
				# }
			}

			if (classifier == "naive_bayes"){
				fit <- naive_bayes(form, train_data)
				prediction <- predict(fit, test_data, type="prob")
				prob <- prediction[,2]
			}
			
			if (cal_importance){
				# calculate variable importance
				importance_scores <- VarImportance(fit, classifier, var_names1, test_data)
				if (is.null(importance_matrix)){
					importance_matrix <- matrix(importance_scores, nrow=1)			}
				else{
					importance_matrix <- rbind(importance_matrix, matrix(importance_scores, nrow=1))
				}
			}

						
			# calculate auc
			result <- roc(test_data[szz_baseline][,1], prob)
			auc_scores <- append(auc_scores, result["auc"][[1]][1])

			# calculate prroc
			auprc <- pr.curve(prob, weights.class0=as.numeric(test_data[szz_baseline][,1]=="buggy"))$auc.integral
			auprc_scores <- append(auprc_scores, auprc)

			# calculate precision
			precision_score <- precision(test_data, prob, szz_baseline)
			precision_scores <- append(precision_scores, precision_score)

			# calculate recall
			recall_score <- recall(test_data, prob, szz_baseline)
			recall_scores <- append(recall_scores, recall_score)

			# calculate f1
			f_score <- F1(test_data, prob, szz_baseline)
			F1_scores <- append(F1_scores, f_score)

			# calculate cost effectiveness measure
			ordered_data <- get_ordered_data(test_data, prob)
			total_churn <- sum(test_data$real_la+test_data$real_ld)
			# raw_ce <- calculate_cost_effectiveness(test_data, ordered_data, szz_baseline)

			# buggy_count <- raw_ce[1]
			# change_count <- raw_ce[2]
			# first_buggy <- raw_ce[3]

			# precision20 <- buggy_count / change_count
			# recall20 <- buggy_count / length(which(test_data[szz_baseline][,1]=="buggy"))
			results <- calculate_cost_effectiveness2(ordered_data, total_churn, 0.2, "real_la", "real_ld", szz_baseline, "buggy")
			precision20 <- results[1]
			recall20 <- results[2]
			F1_score20 <- 2 * precision20 * recall20 / (precision20 + recall20)
			precision20_scores <- append(precision20_scores, precision20)
			recall20_scores <- append(recall20_scores, recall20)
			F1_20_scores <- append(F1_20_scores, F1_score20)
			
			if ("IFA" %in% calculated_measures){
				IFA_scores <- append(IFA_scores, first_buggy - 1)
				inspected_changes <- append(inspected_changes, change_count / nrow(test_data))
			}

			if ("Popt" %in% calculated_measures){
				# Popt_data <- Popt(test_data, ordered_data, szz_baseline, FALSE)

				# optimal <- trapz(Popt_data$ideal_churn, Popt_data$ideal_buggy)
				# print(optimal)
				# method <- trapz(Popt_data$method_churn, Popt_data$method_buggy)
				# popt_value <- 1 - (optimal - method) / (2 * optimal - 1)
				popt_value <- Popt2(ordered_data, total_churn, "real_la", "real_ld", szz_baseline, "buggy")
				popt_values <- append(popt_values, popt_value)
			}

			if ("oneway_p20" %in% calculated_measures){
				scores <- one_way(raw_data[train_indices,], raw_data[-unique(train_indices),], metrics, szz_label, szz_baseline, type="2")
				oneway_p20_scores <- append(oneway_p20_scores, scores[1])
				oneway_r20_scores <- append(oneway_r20_scores, scores[2])
				oneway_f20_scores <- append(oneway_f20_scores, scores[3])
				oneway_popt_values <- append(oneway_popt_values, scores[4])
			}
		}

		if (cal_importance){
			# compute ranks of the features
			importance_frame <- data.frame(importance_matrix)
			names(importance_frame) <- var_names1
			row.names(importance_frame) <- as.character(1:bootstrap_times)
			sk <- sk_esd(importance_frame)
			features <- names(sk$groups)
			groups <- as.vector(sk$groups)
			temp_frame <- data.frame(features, groups)
			names(temp_frame) <- c(paste(szz_label, "_features", sep=""), paste(szz_label, "_groups", sep=""))

			if(is.null(importance_rank_frame)){
				importance_rank_frame <- temp_frame
			}
			else {
				importance_rank_frame <- cbind(importance_rank_frame, temp_frame)
			}
		}

		# store auc results
		print(mean(auc_scores))
		result_frame <- store_result_to_frame(result_frame, auc_scores)

		# store auprc results
		print(mean(auprc_scores))
		result_frame <- store_result_to_frame(result_frame, auprc_scores)

		# store precision
		print(mean(precision_scores))
		result_frame <- store_result_to_frame(result_frame, precision_scores)

		# store recall
		print(mean(recall_scores))
		result_frame <- store_result_to_frame(result_frame, recall_scores)

		# store F1
		print(mean(F1_scores))
		result_frame <- store_result_to_frame(result_frame, F1_scores)

		# store precision20, recall20, F1_score20
		print(mean(precision20))
		print(mean(recall20))
		print(mean(F1_score20))
		result_frame <- store_result_to_frame(result_frame, precision20_scores)
		result_frame <- store_result_to_frame(result_frame, recall20_scores)
		result_frame <- store_result_to_frame(result_frame, F1_20_scores)

		if ("IFA" %in% calculated_measures){
			result_frame <- store_result_to_frame(result_frame, IFA_scores)
			result_frame <- store_result_to_frame(result_frame, inspected_changes)
		}
		
		if ("Popt" %in% calculated_measures){
			result_frame <- store_result_to_frame(result_frame, popt_values)
		}

		if ("oneway_p20" %in% calculated_measures){
			oneway_result_frame <- data.frame(oneway_p20_scores, oneway_r20_scores, oneway_f20_scores, oneway_popt_values)
			result_fn2 <- paste(c(root_path, "test/", p, "_oneway", "_", szz_label, ".csv"), collapse="")
			write.csv(oneway_result_frame, result_fn2, row.names=FALSE)
		}
		names(result_frame) <- calculated_measures2

		# print(szz_label)
		# result_fn <- paste(c(root_path, "results_balance/", p, "_", classifier, "_", szz_label, ".csv"), collapse="")
		# write.csv(result_frame, result_fn, row.names=FALSE)
	}

	imp_fn <- paste(c(root_path, "results_imbalance_raw/", p, "_", classifier, "_importance.csv"), collapse="")
	write.csv(importance_rank_frame, imp_fn, row.names=FALSE)
}
