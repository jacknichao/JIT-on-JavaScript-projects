require(effsize) 
library("car")
library("Hmisc")
library("lme4")
library("rms")
library("aod")
library(sjPlot)
library(ggplot2)

source("C://code-R/JITalibaba-R/packages/base.R")

root_path <- "C://data/JIT-Alibaba/result/"
#methods <- c("CBS", "OneWay", "EALR", "LT")

boxplot <- 1
histogram <- 0

varibles_full_name <- c("LOC", "File", "Meidan_size", "Mean_size", "Commits", "Defective", "Def_ratio", "Devs", "Branches", "Usage", "Stage")
measure_name <- c("F1_score", "IFA", "PCI")

if (boxplot == 1){
  fn_save_summary_extend <- "C://data/JIT-Alibaba/result/summary_extend.csv"
  data <- read.csv(fn_save_summary_extend)

  fn_save_spearman <- "C://data/JIT-Alibaba/result/spearman_result.csv"
  corr_data <- read.csv(fn_save_spearman)
  sub_corr_data <- corr_data[6:16,4:6]

  {
  mytheme <- theme_bw() + 
    theme(plot.title=element_text(size=rel(1.5),hjust=0.5),
          axis.title=element_text(size=rel(2),color = "black"),
          axis.text=element_text(size=rel(2),color = "black"),
          axis.text.x = element_text(angle=30,vjust=0.6),
          panel.grid.major=element_line(color="white"),
          panel.grid.minor=element_line(color="white"),
          panel.border=element_rect(color="gray"),
          axis.line=element_line(color="gray",size=1),
    
          #legend.position = c(.85,.15),
          #legend.position = "right",
          #legend.title = element_text(size=rel(1.3),hjust = 0.5),
          strip.background = element_rect(color = "white",fill = "white"),
          strip.text.x = element_text(size = rel(2),color = "black",face = "bold")
         )
  }


  #data <- generate_factor(data, "sta", threshold_sta)
  spearman_threshold <- 0.5
  for (measure in measure_name){
    #measure <- "PCI"
    m_index <- which(measure_name == measure)
    this_measure_col <- sub_corr_data[,m_index]
    plot_factors <- which(abs(as.numeric(this_measure_col)) > spearman_threshold)
    for (f_index in plot_factors){
      this_factor <- varibles_full_name[f_index]
      #this_factor <- "Def_ratio"
      if (this_factor == "LOC"){
        threshold <- c("100000","200000","300000","400000","500000")
        temp_data <- generate_factor(data, this_factor, threshold)
        #g <- ggplot(temp_data, aes(x = this_factor,y = measure, fill = this_factor))+mytheme      
      }
      else if (this_factor == "File"){
        threshold <- c("1000","2000","3000","4000","5000")
        temp_data <- generate_factor(data, this_factor, threshold)      
      }
      else if (this_factor == "Def_ratio"){
        threshold <- c("0.10","0.20","0.30")
        temp_data <- generate_factor(data, this_factor, threshold)
      }
      else if (this_factor == "Stage"){
        original_str <- c("d", "m")
        levels_str_sta <- c("Development", "Maintenance")
        temp_data <- generate_factor_for_category(data, this_factor,original_str, levels_str_sta)      
      }
      else{

      }
      g <- ggplot(temp_data, aes_string(x = this_factor,y = measure, fill = this_factor))+mytheme
      g <-  g + geom_boxplot(alpha=0.75)
      g <- g + scale_fill_brewer(palette = "Blues")
      g <- g + guides(fill=FALSE)
      g
      ggsave(paste(c(root_path,  "boxplot", this_factor, "_", measure, ".pdf"), collapse=""), width=5, height=5)
   
      #else if (this_factor == "Stage"){
      #  levels_str_sta <- c("Development", "Maintainance")
      # 
      #}
      #data <- generate_factor(data, this_factor, threshold)
    } 
  }
}

if (histogram == 1){
  fn_save_spearman <- "C://data/JIT-Alibaba/result/spearman_result.csv"
  corr_data <- read.csv(fn_save_spearman)
  sub_corr_data <- corr_data[6:16,4:6]

  new_corr_data <- data.frame(factor=c(NA),measure=c(NA), value=c(NA))

  for (factor in varibles_full_name){
    factor_index <- which(varibles_full_name==factor)
    for (measure in measure_name){
      measure_index <- which(measure_name==measure)
      this_value <- sub_corr_data[factor_index,measure_index]
      this_row <- c(factor, measure, this_value)
      new_corr_data <- rbind(new_corr_data, this_row)
    }
  }
  new_corr_data <- new_corr_data[-1,]


  {
  mytheme2 <- theme_bw() + 
    theme(plot.title=element_text(size=rel(0.6),hjust=0.5),
          axis.title=element_text(size=14,color = "black"),
          axis.title.x=element_text(size=14,color = "black", vjust=-1),
          axis.text=element_text(size=11,color = "black"),
          axis.text.x = element_text(angle=60,vjust=1,hjust=1),
          panel.grid.major=element_line(color="white"),
          panel.grid.minor=element_line(color="white"),
          panel.border=element_rect(color="gray70"),
          axis.line=element_line(color="gray70"),
    
          #legend.position = c(.5,.9),
          #legend.direction = "horizontal",
          #legend.position = "top",
          #legend.background=element_rect(
          #colour="gray"),
          
          legend.title = element_text(size=rel(0),hjust = 0.5),
          legend.text = element_text(size=rel(0.8),hjust = 0.5),
          strip.background = element_rect(color = "gray70",fill = "gray90"),
          strip.text.x = element_text(size = 12,color = "black")
          
         )
  }

  g2 <- ggplot(new_corr_data,aes(x=measure,y=as.numeric(value),color=I("black"),fill=measure))+
  geom_bar(stat='identity',position="dodge")+mytheme2+facet_wrap(~as.factor(factor), ncol=11)
  g2 <- g2 + labs(x = "Project-specific factors", y = "Spearman correlation")
  g2 <- g2 + scale_y_continuous(breaks=seq(-1.0, 1.0, by=0.2))
  g2 <- g2 + geom_hline(aes(yintercept=0.5), linetype="dashed", size=0.5, color="red")
  g2 <- g2 + geom_hline(aes(yintercept=-0.5), linetype="dashed", size=0.5, color="red")+guides(fill=FALSE)
  
  #manual <- c("F1_score"="blue20", "IFA"="blue45", "PCI" = "blue70")
  #g2 <- g2 + scale_fill_manual(values=manual)

  g2 <- g2 + scale_fill_brewer(palette = "Blues")

  g2
  ggsave(paste(c(root_path,  "histogram.pdf"), collapse=""), width=12, height=4)
}

