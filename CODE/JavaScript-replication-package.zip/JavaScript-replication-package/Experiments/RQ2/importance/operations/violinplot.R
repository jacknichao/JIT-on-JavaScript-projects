library("pROC")
library("randomForest")
library("reshape")
library("e1071")
library("ScottKnottESD")
library("caret")
library("pracma")
library("ggplot2")
library("vioplot")



root_path <- "C://Rwork/JITalibaba/"

#projects <- c("force", "aonemix")
#projects <- c("force", "aonemix", "scmcenter", "k3", "fundplatform", "idcops", "servercontroller", "trademanager", "xiamiops")
projects <- c("force", "aonemix", "scmcenter", "k3", "fundplatform", "idcops", "servercontroller", "trademanager", "xiamiops", 
	"tradeplatform", "auctionplatform", "governplatform", "malldetailskip", "twb")
frame <- list(null)
for (p in projects){

	index <- which(projects == p)
	fn <- paste(c(root_path, "input/projects/", p, "/",p,".csv"), collapse="")
	print(paste("filename: ", fn, sep=""))
	data <- read.csv(fn)
	data <- data[-which(data$classification == "Merge"),]
	data <- data[-which(data$la+data$ld > 10000 | data$nf > 100), ]
	data$size <- data$la+data$ld
	data$size <- log(data$size+1)
    frame[[index]] <- data$size
}

par(las=1,bty="l")  ## my preferred setting
## set up empty plot
plot(0:1,0:1,type="n",xlim=c(0.5,14.5),ylim=range(frame),
     axes=FALSE,ann=FALSE)
vioplot(frame[[1]], frame[[2]],frame[[3]],frame[[4]],frame[[5]], frame[[6]], frame[[7]], frame[[8]], frame[[9]], frame[[10]], frame[[11]], frame[[12]], frame[[13]], frame[[14]],col = "lightblue",add=TRUE)
axis(side=1,at=1:14,labels=c("P1", "P2","P3","P4","P5","P6","P7","P8","P9","P10","P11","P12","P13","P14"), font = 2, cex.axis = 1.5)
axis(side=2,at=c(0,3,6,9),labels=c("0","20","400","8K"), font = 2, cex.axis = 1.5)
#text(locator(1),"The churn of a change", pos=4, cex = 1.5, srt = 90)