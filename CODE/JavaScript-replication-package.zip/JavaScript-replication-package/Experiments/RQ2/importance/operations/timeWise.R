library("pROC")
library("randomForest")
library("reshape")
library("e1071")
library("ScottKnottESD")
library("caret")
library("pracma")

source("C://Rwork/JITalibaba/packages/measures.R")
source("C://Rwork/JITalibaba/packages/imbalance.R")
source("C://Rwork/JITalibaba/packages/order_data.R")
source("C://Rwork/JITalibaba/packages/base.R")
source("C://Rwork/JITalibaba/packages/one-way.R")

root_path <- "C://Rwork/JITalibaba/"
#collinearity_fn <- paste(root_path, "collinearity.csv", sep="")
#collinearity_features <- read.csv(collinearity_fn)

methods <- c("CBS", "OneWay", "EALR", "LT", "Churn")
#methods <- c("Churn")
#methods <- c("LT")
#szz_labels <- c("buggy_B2", "buggy_AG", "buggy_MA", "buggy_RA")
#szz_baseline <- "buggy_RA"
label <- "contains_bug"
positive_label <- "TRUE"
features <- c("commit_id", "ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt", "is_fix", "contains_bug")
log_features <- c("ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt")
report_measures <- c("precision20", "recall20", "f1measure20", "IFA", "PCI20", "Popt")
filter_features <- c("commit_id", label)

#"activemq", "camel", "derby", "geronimo", "hcommon", "hbase", "mahout", "openjpa", "pig", "tuscany"
#projects <- c("force")
#projects <- c("force", "aonemix", "scmcenter", "k3", "fundplatform", "idcops", "servercontroller", "trademanager", "xiamiops")
projects <- c("force", "aonemix", "scmcenter", "k3", "fundplatform", "idcops", "servercontroller", "trademanager", "xiamiops", 
	"tradeplatform", "auctionplatform", "governplatform", "malldetailskip", "twb")

folds <- 10
#is_combine_train <- FALSE
for (method in methods){
	method_result_frame <- NULL
	for (p in projects){
		# result preparation
		result_frame <- NULL

		#filter_features <- as.vector(collinearity_features[p][,1])
		#filter_features <- append(filter_features, szz_labels)
		fn <- paste(c(root_path, "input/projects/", p, "/",p,".csv"), collapse="")
		print(paste("filename: ", fn, sep=""))
		data <- read.csv(fn)
		#merge_data <- data[which(data$classification == "Merge"),]
		#merge_buggy_data <- data[which(data$classification == "Merge" & data$contains_bug == "TRUE"),]
		#print (paste(c(p, "number of merge:",dim(merge_data)[1], "number of merge&buggy:", dim(merge_buggy_data)[1], "sum of la of these changes:", sum(merge_buggy_data$la)), collapse=" "))
		temp_label <- data[label][,1]
		temp_label <- as.vector(temp_label)
		temp_label[which(temp_label=="False")] <- "FALSE"
		temp_label[which(temp_label=="True")] <- "TRUE"	
		temp_label_factor <- factor(temp_label, order=TRUE, levels=c("FALSE", "TRUE"))
		data[label] <- temp_label_factor
	    data <- data[order(data$time_stamp),] # order by time, increasing order
		data <- data[-which(data$la+data$ld > 10000 | data$nf > 100), ]
		data <- data[-which(data$classification == "Merge"), ]
		var_names <- names(data)
		var_names1 <- var_names[var_names %in% features]
		var_names1 <- var_names1[!var_names1 %in% filter_features]
		var_names_str <- paste(var_names1, collapse="+")
		print(var_names_str)
		#result_frame <- NULL

		form <- as.formula(paste(label, var_names_str, sep=" ~ "))
		var_names2 <- append(var_names1, label)

		temp_data <- data[var_names2]
		data_log <- get_log_data(temp_data, log_features)
		data_log$real_la <- data$la
		data_log$real_ld <- data$ld
		
		# result preparation
		auc_scores <- c()
		brierscores <- c()
		precision_scores <- c()
		recall_scores <- c()
		F1_scores <- c()
		precision20_scores <- c()
		recall20_scores <- c()
		F1_20_scores <- c()
		IFA_scores <- c()
		inspected_changes <- c()
		popt_scores <- c()
		importance_matrix <- NULL

		# factorise labels
		buggy_labels <- factor(data_log[label][,1], order=TRUE, levels=c("FALSE", "TRUE"))
		data_log[label][,1] <- buggy_labels
		#buggy_real_labels <- factor(temp_data[szz_baseline][,1], order=TRUE, levels=c("FALSE", "TRUE"))
		#temp_data[szz_baseline][,1] <- buggy_real_labels
	    train_data <- NULL
		for (i in 1:(folds-1)){
			print(paste("Fold: ", i , sep=""))
			data_num <- nrow(data_log)
			train_start <- 1        
			train_end <- floor(i/(folds+1)*data_num)
			test_start <- train_end + 1
			if (i < folds){
				test_end <- floor((i+1)/(folds+1)*data_num)
			}
			else{
				test_end <- data_num
			}

			#if (is_combine_train){
			#	train_data <- rbind(train_data, data_log[train_start:train_end,])
			#}
			train_data <- data_log[train_start:train_end,]
			test_data <- data_log[test_start:test_end,]

			# undersampling
			train_data <- undersampling(train_data, label)

			# calculate the likelihood scores being "buggy" for changes in testing set
			#if (classifier == "random_forest"){
			#	fit <- randomForest(form, train_data, ntree=100)
			#	prediction <- predict(fit, test_data, type="prob")
			#	prob <- prediction[,2]
			#}
			if (method == "CBS"){
				fit <- glm(form, train_data, family=binomial(link = "logit"))
				prediction <- predict(fit, test_data, type="response")
				prob <- prediction
				ordered_data <- cbs_plus_get_ordered_data(test_data, prob)
			}
			if (method == "EALR"){
				temp_label <- train_data[label]
				#numeric_label <- factor(0,1)
				numeric_label <- as.numeric(which(temp_label=="TRUE"))				
				density <- numeric_label/(train_data$real_la+train_data$real_ld)
				density[is.infinite(density)] <- 0
				train_data$buggy_density <- density 
				form_ealr <- as.formula(paste("buggy_density", var_names_str, sep=" ~ "))
				fit_ealr <- lm(form_ealr, train_data)
				prediction <- predict(fit_ealr, test_data, type="response")
				prob <- prediction
				ordered_data <- ealr_get_ordered_data(test_data, prob)
			}
			# calculate auc
			# 
			
			if (method == "LT"){
				prob <- test_data$lt
				ordered_data <- lt_get_ordered_data(test_data)
			}

			if (method == "Churn"){
				prob <- test_data$real_la+test_data$real_ld
				ordered_data <- churn_get_ordered_data(test_data)
			}

			if (method == "CBS" | method == "EALR" | method == "LT" | method == "Churn"){
								
				# calculate brier scores
				#mean_score <- BrierScore(test_data, prob, label)
				#brierscores <- append(brierscores, mean_score)

				# calculate precision
				#precision_score <- precision(test_data, prob, label)
				#precision_scores <- append(precision_scores, precision_score)

				# calculate recall
				#recall_score <- recall(test_data, prob, label)
				#recall_scores <- append(recall_scores, recall_score)

				# calculate f1
				#f_score <- F1(test_data, prob, label)
				#F1_scores <- append(F1_scores, f_score)

				# calculate cost effectiveness measure
				# CBS+
				# 
				#auc_score <- roc(test_data[label][,1], prob)
				#auc_score <- auc_score["auc"][[1]][1]
				raw_ce <- calculate_cost_effectiveness2(ordered_data, 0.2, "real_la", "real_ld", label)
				buggy_count <- raw_ce[1]
				change_count <- raw_ce[2]
				first_buggy <- raw_ce[3]
			
				popt <- Popt2(ordered_data, "real_la", "real_ld", label)				
			}

			if (method == "OneWay"){
				result <- one_way(train_data, test_data, var_names1, label, type="1")
				buggy_count <- result[1]
				change_count <- result[2]
				first_buggy <- result[3]
				popt <- result[4]
				#auc_score <- result[5]
			}

			precision20 <- buggy_count / change_count
			recall20 <- buggy_count / length(which(test_data[label][,1]==positive_label))
			F1_score20 <- 2 * precision20 * recall20 / (precision20 + recall20)
			if (is.na(F1_score20))
				F1_score20 <- 0

            #auc_scores <- append(auc_scores, auc_score)
			precision20_scores <- append(precision20_scores, precision20)
			recall20_scores <- append(recall20_scores, recall20)
			F1_20_scores <- append(F1_20_scores, F1_score20)
			IFA_scores <- append(IFA_scores, first_buggy - 1)
			inspected_changes <- append(inspected_changes, change_count / nrow(test_data))
			popt_scores <- append(popt_scores, popt)

		}

		# store auc results
		#print(mean(auc_scores))
		

		# store brier scores
		#print(mean(brierscores))
		#result_frame <- store_result_to_frame(result_frame, brierscores)

		# store precision
		#print(mean(precision_scores))
		#result_frame <- store_result_to_frame(result_frame, precision_scores)

		# store recall
		#print(mean(recall_scores))
		#result_frame <- store_result_to_frame(result_frame, recall_scores)

		# store F1
		#print(mean(F1_scores))
		#result_frame <- store_result_to_frame(result_frame, F1_scores)

		# store precision20, recall20, F1_score20
		#print(mean(precision20))
		#print(mean(recall20))
		#print(mean(F1_score20))
		#print(mean(popt_scores))
		#result_frame <- store_result_to_frame(result_frame, auc_scores)
		result_frame <- store_result_to_frame(result_frame, precision20_scores)
		result_frame <- store_result_to_frame(result_frame, recall20_scores)
		result_frame <- store_result_to_frame(result_frame, F1_20_scores)
		result_frame <- store_result_to_frame(result_frame, IFA_scores)
		result_frame <- store_result_to_frame(result_frame, inspected_changes)  #PCI
		result_frame <- store_result_to_frame(result_frame, popt_scores)

		names(result_frame) <- report_measures

		result_dir <- paste(c(root_path, "output/", p, "_result/"), collapse="")
		result_fn <- paste(c(result_dir, p, "_", method, "_time_wise.csv"), collapse="")

		if (!dir.exists(result_dir))
			dir.create(result_dir)
		write.csv(result_frame, result_fn, row.names=FALSE)

		project_means <- colMeans(as.matrix(result_frame))
		method_result_frame <- store_result_to_frame(method_result_frame, project_means)
	}	
 	names(method_result_frame) <- projects
    row.names(method_result_frame) <- report_measures

    temp_matrix <- as.matrix(method_result_frame)
    ave <- rowMeans(temp_matrix)
    method_result_frame$average <- ave

	result_method_fn <- paste(c(root_path, "output/means_", method, "_time_wise.csv"), collapse="")
	write.csv(t(method_result_frame), result_method_fn, row.names = TRUE)
}


