require(effsize) 
library("car")
library("Hmisc")
library("lme4")
library("rms")
library("aod")
library(sjPlot)
library(ggplot2)

source("C://code-R/JITalibaba-R/packages/base.R")

root_path <- "C://code-R/JITalibaba-R/"
#methods <- c("CBS", "OneWay", "EALR", "LT")
methods <- c("CBS")
report_measures <- c("precision20", "recall20", "f1measure20", "IFA", "PCI20")
#report_measures <- c("recall20","IFA", "PCI20")
projects <- c("force", "aonemix", "scmcenter", "k3", "fundplatform", "idcops", "servercontroller", "trademanager", "xiamiops", 
  "tradeplatform", "auctionplatform", "governplatform", "malldetailskip", "twb")
category <- c("s","s","s","s","b","s","s","b","b","b","b","b","b","b") #s: support  b: business
project_size_loc <- c(93111,189742,56691,326857,285887,135976,110049,248887,33896,326710,434975,130017,86783,422540)
project_size_file <- c(1243,2380,847,2100,3986,976,892,3082,330,3830,4467,1288,1001,4323)
branches <- c(263,821,180,1095,875,55,289,1258,605,985,1765,633,1338,1279)
stage <- c("d","m","m","m","m","d","d","m","d","m","m","m","m","m")
stage_p <- c("m","d","m","d","m","d","d","m","d","m","m","d","d","m")
stage_t <- c("m","d","m","m","m","d","d","m","m","d","m","m","m","m")
label <- "contains_bug"
positive_label <- "TRUE"

method_performance_url1 <- paste(c(root_path, "output/means_", methods[1], "_time_wise.csv"), collapse="")
method_performance1 <- read.csv(method_performance_url1)

f1measure20 <- method_performance1$f1measure20
f1measure20 <- f1measure20[1:14]

precision20 <- method_performance1$precision20
precision20 <- precision20[1:14]

recall20 <- method_performance1$recall20
recall20 <- recall20[1:14]

PCI20 <- method_performance1$PCI20
PCI20 <- PCI20[1:14]

IFA <- method_performance1$IFA
IFA <- IFA[1:14]

median_change_size <- c(1:14)
mean_change_size <- c(1:14)
commits <- c(1:14)
defects <- c(1:14)
ratio <- c(1:14)
developers <- c(1:14)

for (project in projects){
  index <- which(projects==project)
  project_data_url <- paste(c(root_path, "input/projects2/", project, ".csv"), collapse="")
  project_data <- read.csv(project_data_url)

  temp_label <- project_data[label][,1]
  temp_label <- as.vector(temp_label)
  temp_label[which(temp_label=="False")] <- "FALSE"
  temp_label[which(temp_label=="True")] <- "TRUE" 
  temp_label_factor <- factor(temp_label, order=TRUE, levels=c("FALSE", "TRUE"))
  project_data[label] <- temp_label_factor
  num_commits <- dim(project_data)[1]  
  num_defective <- length(which(project_data[label] == positive_label))
  ratio_defective <- num_defective/num_commits
  num_developer <- length(unique(project_data$author_email))

  data <- project_data[-which(project_data$classification == "Merge"),]
  data <- data[-which(project_data$la+project_data$ld > 10000 | project_data$nf > 100), ]
  data$la[is.na(data$la)] <- 0
  data$ld[is.na(data$ld)] <- 0
  data$size <- data$la+data$ld
  median_size <- median(data$size)
  mean_size <- mean(data$size)

  median_change_size[index] <- median_size
  mean_change_size[index] <- mean_size 
  commits[index] <- num_commits
  defects[index] <- num_defective
  ratio[index] <- ratio_defective
  developers[index] <- num_developer
}


project_summary <- data.frame(project=projects, f1measure20=f1measure20, precision20=precision20, recall20=recall20, PCI20=PCI20, IFA=IFA,
 loc=project_size_loc, file=project_size_file,stage=stage_t,category=category, median_change_size=median_change_size, 
 mean_change_size=mean_change_size, commits=commits, defects=defects, ratio=ratio, developers=developers, category=category, branch=branches, stage=stage, stage_t=stage_t)


pre <- project_summary$precision20
rec <- project_summary$recall20
f1 <- project_summary$f1measure20
ifa <- project_summary$IFA
pci <- project_summary$PCI20
loc <- project_summary$loc
fil <-project_summary$file
med <-project_summary$median_change_size
mea <-project_summary$mean_change_size
com <-project_summary$commits
def <-project_summary$defects
rat <-project_summary$ratio
dev <-project_summary$developers
bra <-project_summary$branch
cat <-project_summary$category
sta <-project_summary$stage

x<-data.frame(pre, rec, f1, ifa, pci, loc, fil, med, mea, com, def, rat, dev, bra, cat, sta)
#x<-cbind(pre, rec, f1, ifa, pci, loc, fil, med, mea, com, def, rat, dev)
#x<- data.frame(x)

# cor(x, method = "spearman")
# temp_table <- xtabs(~category+f1measure20, project_summary)
#   print(chisq.test(temp_table))

# temp_table <- xtabs(~stage+f1measure20, project_summary)
#   print(chisq.test(temp_table))

# temp_table <- xtabs(~category+f1measure20, project_summary)
#   print(chisq.test(temp_table))

# temp_table <- xtabs(~f1measure20+stage_t, project_summary)
#   print(chisq.test(temp_table))

varibles <- c("loc", "fil", "med", "mea", "com", "def", "rat", "dev", "bra", "cat", "sta")
varibles_full_name <- c("LOC", "File", "Meidan_size", "Mean_size", "Commits", "Defective", "Def_ratio", "Devs", "Branches", "Usage", "Stage")
#varibles <- c("loc", "fil", "med", "mea", "com", "def", "rat", "dev")
varible_str <- paste(varibles, collapse="+")

spearman_analysis <- 0
wald_test <-0
output_summary <- 1
output_partial_effect <- 0

if (spearman_analysis == 1){
  temp<-cbind(pre, rec, f1, ifa, pci, loc, fil, med, mea, com, def, rat, dev, bra, cat, sta)
  corr_result <- cor(temp, method = "spearman")
  corr_result <- data.frame(corr_result)
  fn_save_spearman <- paste(c("C://data/JIT-Alibaba/result/spearman_result.csv"), collapse="")
  write.csv(corr_result, fn_save_spearman, row.names=TRUE)
}


if (wald_test == 1){
  target_measures <- c("f1", "pci", "ifa")
  adj_r2 <- NULL
  for (target_measure in target_measures){

    form <- as.formula(paste(target_measure, varible_str, sep=" ~ "))
    fit <- lm(form, data = x)
    summary_fit <- summary(fit)
    adj_r2 <- append(adj_r2, summary_fit$adj.r.squared)
    measure_result <- data.frame(feature=c(NA), chi2=c(NA), df=c(NA), pvalue=c(NA))

    for (var in varibles){
      index <- which(varibles == var)
      wald_test <- wald.test(b = coef(fit), Sigma = vcov(fit), Terms = index)
      result <- wald_test$result$chi2
      this_feature <- append(var, result)
      measure_result <- rbind(measure_result, this_feature)
    }

    measure_result <- measure_result[-1,] 
    measure_result$feature <- varibles_full_name
    measure_result <- measure_result[order(as.numeric(measure_result$chi2), decreasing =TRUE),]
    measure_result <- normalize_chi2(measure_result, "chi2")

    fn_save_wald <- paste(c("C://data/JIT-Alibaba/result/wald_", target_measure, ".csv"), collapse="")
    write.csv(measure_result, fn_save_wald, row.names=FALSE)
  }
  print(adj_r2)
}


if (output_summary == 1) {
  
  summary <- cbind(projects,x)

  #extended summary
  extend_summary <- summary
  extend_summary <- extend_summary[-c(1:dim(summary)[1]),] 
  fixed_features <- c("loc", "fil", "med", "mea", "com", "def", "rat", "dev", "bra", "cat", "sta")

  for (project in projects){
    index <- which(projects==project)
    this_pro_sum <- summary[index,]
    fixed_data <- this_pro_sum[fixed_features]

    project_result_url <- paste(c(root_path, "output/", project, "_result/", project, "_CBS_time_wise.csv"), collapse="")
    project_result <- read.csv(project_result_url)

    for (i in c(1:dim(project_result)[1])){
       performance <- project_result[i,(1:5)]
       extend_per <- cbind(project, performance, fixed_data)
       extend_summary <- rbind(extend_summary, extend_per)
    }
  }

  
  summary_names <- append(c("Project", "Precision", "Recall", "F1_score", "IFA", "PCI"),varibles_full_name)
  names(summary) <- summary_names
  names(extend_summary) <- summary_names
  fn_save_summary <- "C://data/JIT-Alibaba/result/summary.csv"
  write.csv(summary, fn_save_summary, row.names=FALSE)

  fn_save_summary_extend <- "C://data/JIT-Alibaba/result/summary_extend.csv"
  write.csv(extend_summary, fn_save_summary_extend, row.names=FALSE)
}


if (output_partial_effect == 1){
    {
    mytheme <- theme_bw() + 
      theme(plot.title=element_text(size=rel(0),hjust=0.5),
            axis.title.y=element_text(size=rel(2.2),color = "black"),
            axis.title.x=element_text(size=rel(0),color = "black"),
            axis.text=element_text(size=rel(2.2),color = "black"),
            axis.text.x = element_text(angle=0,vjust=0.6),
            panel.grid.major=element_line(color="gray"),
            panel.grid.minor=element_line(color="gray"),
            panel.border=element_rect(color="black"),
            axis.line=element_line(color="gray",size=1),
      
            legend.position = c(.85,.15),
            #legend.position = "bottom",
            legend.title = element_text(size=rel(1.3),hjust = 0.5),
            strip.background = element_rect(color = "white",fill = "white"),
            strip.text.x = element_text(size = rel(2),color = "black",face = "bold")
           )
    }

    target_measure <- "f1"
    form <- as.formula(paste(target_measure, varible_str, sep=" ~ "))
    fit <- lm(form, data = x)
    measure_result <- data.frame(feature=c(NA), chi2=c(NA), df=c(NA), pvalue=c(NA))
    varibles_plot <- c("loc", "dev", "mea", "sta", "bra")
    #varibles_plot <- c("sta")
    varibles_full_name <- c("#LOC", "#Devs", "Meadian size", "Stage", "#Branches")
    for (var in varibles_plot){
      index <- which(varibles_plot==var)
      plot_model(fit, type = "pred", terms = var)+mytheme+ylab("Estimated Partial Effect")+xlab(varibles_full_name[index])
      fn_save_plot <- paste(c("C://data/JIT-Alibaba/result/effect_", var, ".pdf"), collapse="")
      ggsave(fn_save_plot, width=6, height=6)
    }
}

