library("pROC")
library("randomForest")
library("reshape")
library("e1071")
library("ScottKnottESD")
library("caret")
library("pracma")


root_path <- "C://Rwork/JITalibaba/"

#projects <- c("tradeplatform")

projects <- c("force", "aonemix", "scmcenter", "k3", "fundplatform", "idcops", "servercontroller", "trademanager", "xiamiops", 
"tradeplatform", "auctionplatform", "governplatform", "malldetailskip", "twb")

for (p in projects){
	# result preparation
	#filter_features <- as.vector(collinearity_features[p][,1])
	#filter_features <- append(filter_features, szz_labels)
	fn <- paste(c(root_path, "input/projects/", p, "/", p, ".csv"), collapse="")
	data <- read.csv(fn)
 	data <- data[order(data$commit_id),]
	fn2 <- paste(c(root_path, "input/projects/report-1025/", p, ".csv"), collapse="")
	data_new <- read.csv(fn2)
	data_new <- data_new[order(data_new$commit_id),]
	outputurl <- paste(c(root_path, "input/projects2/", p, ".csv"), collapse="")

    data_2 <- data[which(data$commit_id %in% data_new$commit_id),]
	
    data_new2 <- data_new[which(data_new$commit_id %in% data_2$commit_id),]


	data_2$entropy <- data_new2$entropy

	data_2 <- data_2[order(data$time_stamp, decreasing="TRUE"),]

   
	write.csv(data_2, outputurl, row.names=FALSE)

    #summary <- append (summary, c(p, num_commits, num_defective, ratio_defective, num_developer, time_start, time_end))
}




