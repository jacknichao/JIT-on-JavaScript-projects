rm(list=ls())
require(caret)
require(e1071)
require(Hmisc)
library(rms)


# the variable is used to set which projects should be analyzed
projects_name <- "jsprojects"
#projects_name <- "javaprojects"

collinearity <- read.csv(paste("./collinearity-analysed.csv", sep=""))
 

root_path <- paste(c("preprocess/", projects_name,"-jshtml", "/"), collapse="")

js_projects <- c("vue","react","axios","three.js","jquery","webpack","material-ui","express","Chart.js","moment","meteor","lodash","yarn","babel","parcel","anime","serverless","Ghost","hyper","pdf.js")
java_projects <- c("activemq", "camel", "derby", "geronimo", "hbase", "hcommon", "mahout", "openjpa", "pig", "tuscany")

if (projects_name == "jsprojects"){
	studied_projects <- js_projects
} else if (projects_name == "javaprojects"){
	studied_projects <- java_projects
} else{
  print("error project_name")
}



for (project in studied_projects){
	print(project)
  # the '-' will be escaped as '.'
  if (project == "material-ui"){
    cor_features <- collinearity[,'material.ui']
  }else{
	  cor_features <- collinearity[,project]
  }
  
	data_path <- paste(c(root_path, project, ".csv"), collapse="")
	label <- "contains_bug"
	data <- read.csv(data_path)
	vars <- names(data)
	var_names1 <- vars[vars != label]
	var_names1 <- var_names1[!var_names1 %in% cor_features]

	var_str <- paste(var_names1, collapse="+")
	form_str <- paste("~", var_str, sep="")
	redun_form <- as.formula(form_str)
	#print(redun_form)
	out=redun(redun_form, data, nk=0)
	print(out)


}
print("redun analysis done!!")


