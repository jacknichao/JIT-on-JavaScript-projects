rm(list=ls())
source("./packages/base.R")

features <- c("ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt", "is_fix", "contains_bug","HtmlCss","Strict","BDom","SO","TC")
log_features <- c("ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt","HtmlCss","Strict","BDom","SO","TC")

js_projects <- c("vue","react","axios","three.js","jquery","webpack","material-ui","express","Chart.js","moment",
                  "meteor","lodash","yarn","babel","parcel","anime","serverless","Ghost","hyper","pdf.js")

projects_name <- "jsprojects"
root_path <- paste(c("preprocess/", projects_name,"-jshtml", "/"), collapse="")
label <- "contains_bug"

result_fn <- paste(c("./combined-collinearity_", projects_name, ".txt"), collapse="")
cat("", file=result_fn, append=FALSE)

preprocess_js <- function(data){
	temp_label <- data[label][,1]
	temp_label <- as.vector(temp_label)
	temp_label[which(temp_label=="False")] <- "clean"
	temp_label[which(temp_label=="True")] <- "buggy"
	#temp_label[which(temp_label=="FALSE")] <- "clean"
	#temp_label[which(temp_label=="TRUE")] <- "buggy"
	data[,label] <- temp_label	
	#data <- data[-which(data$classification=="Merge"),]
	#data <- data[-which(data$la + data$ld > 10000 | data$nf > 100),]
	
	real_la <- data$la
	real_ld <- data$ld
	
	indexes <- which(data$lt != 0)
	normalized_la <- rep(0, nrow(data))
	normalized_ld <- rep(0, nrow(data))
	normalized_la[indexes] <- data$la[indexes] / data$lt[indexes] / data$nf[indexes]
	normalized_ld[indexes] <- data$ld[indexes] / data$lt[indexes] / data$nf[indexes]
	data$la <- normalized_la
	data$ld <- normalized_ld
	print("preprocess javascript")
	data_log <- get_log_data(data, log_features)
	
	data_log$real_la <- real_la
	data_log$real_ld <- real_ld
	
	return(data_log)
}


# combine all project data into one set
combined_data <- NULL
for (project in js_projects){
  change_data_url <- paste(c("preprocess/jsprojects-jshtml/", project, ".csv"), collapse="")
  changes <- read.csv(change_data_url) 
  combined_data <- rbind(combined_data, changes[features])
}





print(paste("Analysing Combined Dataset Correlation:",projects_name,"File Name:", project,sep = "  "))

# filter useless features 
combined_data <-combined_data[features]
#combined_data <- preprocess_js(combined_data)
 
combined_data <-combined_data[features]
vars <- names(combined_data)

var_names1 <- vars[vars != label]

correlations <- cor(combined_data[var_names1], combined_data[var_names1], method="spearman")

for (i in 1:(length(var_names1)-1)){
	for (j in (i+1):length(var_names1)){
		corr_val <- correlations[var_names1[i], var_names1[j]]
		if (corr_val > 0.8 | corr_val < -0.8){
		  #ifea <- cor(data[var_names1[i]], as.numeric(data[label]))
		  #print(ifea)
			print(paste(c(var_names1[i], var_names1[j], ":", as.character(corr_val), "\n"), collapse=" "))
		}
	}
}
