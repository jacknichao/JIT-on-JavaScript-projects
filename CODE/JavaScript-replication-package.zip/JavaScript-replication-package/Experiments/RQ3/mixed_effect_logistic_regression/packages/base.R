


get_log_data<-function(temp_data, log_features){
	for (feature in log_features){
		temp_vec <- temp_data[,feature]
		temp_vec[is.na(temp_vec)] <- 0
		temp_vec <- as.vector(temp_vec)
		temp_vec_num <- as.numeric(temp_vec)
		temp_vec_num[is.na(temp_vec_num)] <- 0	
		temp_vec_num[temp_vec_num>0] <- log(temp_vec_num[temp_vec_num>0]+1)
		temp_data[feature] <- temp_vec_num
		#print(feature)
	}

	return(temp_data)
}


store_result_to_frame<-function(result_frame, scores_vector){
	temp_frame <- data.frame(scores_vector)
	if (is.null(result_frame)){
		result_frame <- temp_frame
		}
	else {
		result_frame <- cbind(result_frame, temp_frame)
	}
	return(result_frame)
}

generate_factor <- function(data, co, threshold){
	return_data <- data[order(as.numeric(as.character(data[co][,1]))),]
	levels_str <- NULL
	temp <- return_data[co]
	start <- 0
	for (i in threshold){
		index <- which(threshold==i)
		end <- i		
		this_index <- which(threshold == i)
		if (this_index == length(threshold)){
			temp[which(as.numeric(temp[,1]) <= as.numeric(end) & as.numeric(temp[,1]) > as.numeric(start)),] <- paste(c(">",to_short_character(start)), collapse="")
			levels_str <- append(levels_str, paste(c(">",to_short_character(start)), collapse=""))
		}
		else{
			temp[which(as.numeric(temp[,1]) <= as.numeric(end) & as.numeric(temp[,1]) > as.numeric(start)),] <- paste(c(to_short_character(start),to_short_character(end)), collapse="-")
			levels_str <- append(levels_str, paste(c(to_short_character(start),to_short_character(end)), collapse="-"))
		}
		start <- i	
	}
	print(levels_str)
	#temp2 <- as.factor(temp[,1],order=TRUE, levels = levels_str)
	temp2 <- as.factor(temp[,1])
	temp3 <- factor(temp2, order=TRUE, levels=levels_str)
	return_data[co] <- temp3

	return(return_data)
}

to_short_character <- function(char){
	
	return_char <- char

	number <- as.numeric(char)

	if (number >= 1000){
		k <- floor(number / 1000 + 0.5)
		return_char <- paste(c(k, "K"), collapse="")
	}

	if (number < 1)
	   return_char <-  as.character(round(number,2))

    

	return(return_char)
}



generate_factor_for_category <- function(data, co, original_str, levels_str){
	#data <- data[order(as.numeric(as.character(data[co][,1]))),]
	temp <- as.character(data[co][,1])
	temp[which(temp==original_str[1])] <- levels_str[1]
	temp[which(temp==original_str[2])] <- levels_str[2]
	print(levels_str)
	#temp2 <- as.factor(temp[,1],order=TRUE, levels = levels_str)
	temp2 <- as.factor(temp)
	temp3 <- factor(temp2, order=TRUE, levels=levels_str)
	data[co] <- temp3

	return(data)
}


normalize_chi2 <- function(data, co){
	temp <- data[co][,1]
	sum <- sum(as.numeric(temp))
	temp <- as.numeric(temp)/sum

	data[co] <- temp

	return(data)
}


get_randomeff_models <- function(id) {
  random.eff.formula <- c()
  random.eff.formula[[1]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)+(1|com)+(1|def)+(1|rat)+(1|dev)+(1|bra)+(1|cat)
  random.eff.formula[[2]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)+(1|com)+(1|def)+(1|rat)+(1|dev)+(1|bra)
  random.eff.formula[[3]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)+(1|com)+(1|def)+(1|rat)+(1|dev)
  random.eff.formula[[4]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)+(1|com)+(1|def)+(1|rat)
  random.eff.formula[[5]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)+(1|com)+(1|def)
  random.eff.formula[[6]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)+(1|com)
  random.eff.formula[[7]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)+(1|mea)
  random.eff.formula[[8]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)+(1|med)
  random.eff.formula[[9]] <- contains_bug ~  ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)+(1|fil)
  random.eff.formula[[10]] <- contains_bug ~ ns+nd+nf+exp+ndev+age+la+ld+lt+is_fix+(1|loc)

  
  # if (id == 1 || id == 5 || id == 7) {
  #   tmp_mixed_model <- glmer(random.eff.formula[[id]], 
  #                            data = combined_all_changes_factors, family = "binomial")
  # }
  # else {
    tmp_mixed_model <- glmer(random.eff.formula[[id]], 
                             data = combined_all_changes_factors, family = "binomial", 
                             control=glmerControl(optimizer="optimx",
                                                  optCtrl=list(method="nlminb")))
  # }
  
  return(tmp_mixed_model)
}

add_statis_rq1_supervised <- function(data){
	temp_data <- data[1:(dim(data)[1]-2),] # remove average improve
    names <- names(temp_data)
	p_value_2 <- get_pvalue(temp_data, names[4], names[2])
	cliff_2 <- get_cliff (temp_data, names[4], names[2])
	p_value_3 <- get_pvalue(temp_data, names[4], names[3])
	cliff_3 <- get_cliff (temp_data, names[4], names[3])
	p_value_5 <- get_pvalue_small(temp_data, names[7], names[5])
	cliff_5 <- get_cliff_small (temp_data, names[7], names[5])
	p_value_6 <- get_pvalue_small(temp_data, names[7], names[6])
	cliff_6 <- get_cliff_small (temp_data, names[7], names[6])
	p_value_8 <- get_pvalue(temp_data, names[10], names[8])
	cliff_8 <- get_cliff(temp_data, names[10], names[8])
	p_value_9 <- get_pvalue(temp_data, names[10], names[9])
	cliff_9 <- get_cliff (temp_data, names[10], names[9])
	p_value_11 <- get_pvalue_small(temp_data, names[13], names[11])
	cliff_11 <- get_cliff_small (temp_data, names[13], names[11])
	p_value_12 <- get_pvalue_small(temp_data, names[13], names[12])
	cliff_12 <- get_cliff_small (temp_data, names[13], names[12])
	p_value_14 <- get_pvalue_small(temp_data, names[16], names[14])
	cliff_14 <- get_cliff_small (temp_data, names[16], names[14])
	p_value_15 <- get_pvalue_small(temp_data, names[16], names[15])
	cliff_15 <- get_cliff_small (temp_data, names[16], names[15])
	p_value_17 <- get_pvalue(temp_data, names[19], names[17])
	cliff_17 <- get_cliff (temp_data, names[19], names[17])
	p_value_18 <- get_pvalue(temp_data, names[19], names[18])
	cliff_18 <- get_cliff (temp_data, names[19], names[18])
	p_value_20 <- get_pvalue(temp_data, names[22], names[20])
	cliff_20 <- get_cliff (temp_data, names[22], names[20])
	p_value_21 <- get_pvalue(temp_data, names[22], names[21])
	cliff_21 <- get_cliff (temp_data, names[22], names[21])
    first_col_name <- names(data)[1]
    number_rows <- dim(data)[1]
    number_cols <- dim(data)[2]

    string_first_col <- as.character(data[,1])
    string_first_col <- append(string_first_col, "p_value")
    string_first_col <- append(string_first_col, "Cliff's delta")

    data[,1] <- NULL
    data[number_rows+1, ] <- c(p_value_2,p_value_3, " ", p_value_5,p_value_6, " ", p_value_8, p_value_9," ", 
    	p_value_11,p_value_12, " ", p_value_14,p_value_15, " ", p_value_17,p_value_18, " ", p_value_20, 
    	p_value_21," ")

    data[number_rows+2, ] <- c(cliff_2,cliff_3, " ", cliff_5, cliff_6," ", cliff_8,cliff_9, " ",
     cliff_11,cliff_12, " ",cliff_14,cliff_15, " ", cliff_17, cliff_18," ", cliff_20, cliff_21," ")

    data <- cbind(string_first_col, data)
    names(data)[1] <- first_col_name
    return(data)
}

add_statis_rq1_unsupervised <- function(data){
	temp_data <- data[1:(dim(data)[1]-2),] # remove average improve
    names <- names(temp_data)
	p_value_2 <- get_pvalue(temp_data, names[4], names[2])
	cliff_2 <- get_cliff (temp_data, names[4], names[2])
	p_value_3 <- get_pvalue(temp_data, names[4], names[3])
	cliff_3 <- get_cliff (temp_data, names[4], names[3])
	p_value_5 <- get_pvalue(temp_data, names[7], names[5])
	cliff_5 <- get_cliff (temp_data, names[7], names[5])
	p_value_6 <- get_pvalue_small(temp_data, names[7], names[6])
	cliff_6 <- get_cliff_small (temp_data, names[7], names[6])
	p_value_8 <- get_pvalue(temp_data, names[10], names[8])
	cliff_8 <- get_cliff(temp_data, names[10], names[8])
	p_value_9 <- get_pvalue(temp_data, names[10], names[9])
	cliff_9 <- get_cliff (temp_data, names[10], names[9])
	p_value_11 <- get_pvalue_small(temp_data, names[13], names[11])
	cliff_11 <- get_cliff_small (temp_data, names[13], names[11])
	p_value_12 <- get_pvalue_small(temp_data, names[13], names[12])
	cliff_12 <- get_cliff_small (temp_data, names[13], names[12])
	p_value_14 <- get_pvalue_small(temp_data, names[16], names[14])
	cliff_14 <- get_cliff_small (temp_data, names[16], names[14])
	p_value_15 <- get_pvalue_small(temp_data, names[16], names[15])
	cliff_15 <- get_cliff_small (temp_data, names[16], names[15])
	p_value_17 <- get_pvalue(temp_data, names[19], names[17])
	cliff_17 <- get_cliff (temp_data, names[19], names[17])
	p_value_18 <- get_pvalue(temp_data, names[19], names[18])
	cliff_18 <- get_cliff (temp_data, names[19], names[18])
	p_value_20 <- get_pvalue(temp_data, names[22], names[20])
	cliff_20 <- get_cliff (temp_data, names[22], names[20])
	p_value_21 <- get_pvalue(temp_data, names[22], names[21])
	cliff_21 <- get_cliff (temp_data, names[22], names[21])
    first_col_name <- names(data)[1]
    number_rows <- dim(data)[1]
    number_cols <- dim(data)[2]

    string_first_col <- as.character(data[,1])
    string_first_col <- append(string_first_col, "p_value")
    string_first_col <- append(string_first_col, "Cliff's delta")

    data[,1] <- NULL
    data[number_rows+1, ] <- c(p_value_2,p_value_3, " ", p_value_5,p_value_6, " ", p_value_8, p_value_9," ", 
    	p_value_11,p_value_12, " ", p_value_14,p_value_15, " ", p_value_17,p_value_18, " ", p_value_20, 
    	p_value_21," ")

    data[number_rows+2, ] <- c(cliff_2,cliff_3, " ", cliff_5, cliff_6," ", cliff_8,cliff_9, " ",
     cliff_11,cliff_12, " ",cliff_14,cliff_15, " ", cliff_17, cliff_18," ", cliff_20, cliff_21," ")

    data <- cbind(string_first_col, data)
    names(data)[1] <- first_col_name
    return(data)
}

get_pvalue <- function(data, col1, col2){  # bigger one is col1
	num_projects <- 12
	ret <- wilcox.test(data[col1][,1], data[col2][,1], alternative="g", var.equal=FALSE, paired = TRUE, conf.level=0.95)
	p_value <- ret["p.value"][[1]]  
	adjusted_pvalue <- p_value * num_projects

	if (adjusted_pvalue <= 0.001){
      p_value_str <- "<0.001"
    }
    if (adjusted_pvalue <= 0.01 & adjusted_pvalue >0.001){
      p_value_str <- "<0.01"
    }
    if(adjusted_pvalue <= 0.05 & adjusted_pvalue > 0.01){
      p_value_str <- "<0.05"
    }
    if (adjusted_pvalue > 0.05){
      p_value_str <- ">0.05"
    }
 	
    return(p_value_str)
}

get_pvalue_small <- function(data, col1, col2){
	num_projects <- 12
	ret <- wilcox.test(data[col1][,1], data[col2][,1], alternative="l", var.equal=FALSE, paired = TRUE, conf.level=0.95)
	p_value <- ret["p.value"][[1]]  
	adjusted_pvalue <- p_value * num_projects

	if (adjusted_pvalue <= 0.001){
      p_value_str <- "<0.001"
    }
    if (adjusted_pvalue <= 0.01 & adjusted_pvalue >0.001){
      p_value_str <- "<0.01"
    }
    if(adjusted_pvalue <= 0.05 & adjusted_pvalue > 0.01){
      p_value_str <- "<0.05"
    }
    if (adjusted_pvalue > 0.05){
      p_value_str <- ">0.05"
    }
 	
    return(p_value_str)
}

get_cliff <- function(data, col1, col2){  # bigger one is col1
	ret <- cliff.delta(data[col1][,1], data[col2][,1])
	estimation <- ret["estimate"][[1]]
    estimation <- round(estimation, 2)
    if (ret["magnitude"] == 1){
      magnitude <- "(N)"
    }
    if (ret["magnitude"] == 2){
      magnitude <- "(S)"
    }
    if (ret["magnitude"] == 3){
      magnitude <- "(M)"
    }
    if (ret["magnitude"] == 4){
      magnitude <- "(L)"
    }

    cliff_str <- paste(c(estimation, magnitude), collapse="")
	return(cliff_str)
}

get_cliff_small <- function(data, col1, col2){  # bigger one is col1
	ret <- cliff.delta(data[col2][,1], data[col1][,1])
	estimation <- ret["estimate"][[1]]
    estimation <- round(estimation, 2)
    if (ret["magnitude"] == 1){
      magnitude <- "(N)"
    }
    if (ret["magnitude"] == 2){
      magnitude <- "(S)"
    }
    if (ret["magnitude"] == 3){
      magnitude <- "(M)"
    }
    if (ret["magnitude"] == 4){
      magnitude <- "(L)"
    }

    cliff_str <- paste(c(estimation, magnitude), collapse="")
	return(cliff_str)
}
