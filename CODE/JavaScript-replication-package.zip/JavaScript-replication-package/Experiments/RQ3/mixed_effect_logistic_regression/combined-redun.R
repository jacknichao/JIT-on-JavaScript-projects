rm(list=ls())
require(caret)
require(e1071)
require(Hmisc)
library(rms)


# the variable is used to set which projects should be analyzed
projects_name <- "jsprojects"



# the results obtained by run "combined-collinearity.R"
cor_features<-c('ns','entropy','ndev','nuc','ld','rexp')




features <- c("ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt", "is_fix", "contains_bug","HtmlCss","Strict","BDom","SO","TC")
js_projects <- c("vue","react","axios","three.js","jquery","webpack","material-ui","express","Chart.js","moment",
                 "meteor","lodash","yarn","babel","parcel","anime","serverless","Ghost","hyper","pdf.js")

# combine all project data into one set
combined_data <- NULL
for (project in js_projects){
  change_data_url <- paste(c("preprocess/jsprojects-jshtml/", project, ".csv"), collapse="")
  changes <- read.csv(change_data_url) 
  combined_data <- rbind(combined_data, changes[features])
}

label <- "contains_bug"
 
vars <- names(combined_data)
var_names1 <- vars[vars != label]
var_names1 <- var_names1[!var_names1 %in% cor_features]

var_str <- paste(var_names1, collapse="+")
form_str <- paste("~", var_str, sep="")
redun_form <- as.formula(form_str)
#print(redun_form)
out=redun(redun_form, combined_data, nk=0)
print(out)

 


