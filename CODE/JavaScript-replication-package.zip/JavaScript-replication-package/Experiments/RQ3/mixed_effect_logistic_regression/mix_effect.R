#rm(list=ls())
library(optimx)
library("lme4")
library("MuMIn")
library("car")
source("packages/base.R")

library(boot)
library(plyr)
library(doParallel)



jsfeatures <- c('htmlcss','strict','bdom','so','tc')
print(jsfeatures)


#js projects name
js_projects <- c("vue","react","axios","three.js","jquery","webpack","material-ui","express","Chart.js","moment",
                 "meteor","lodash","yarn","babel","parcel","anime","serverless","Ghost","hyper","pdf.js")
label <- "contains_bug"

# context features of projects
factors_with_project<-c("project","stars","fork","branch","change","defective","defratio","file","loc","contributor","mediann","meann")
factors <- c("stars","fork","branch","change","defective","defratio","file","loc","contributor","mediann","meann")

features <- c("ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt", "is_fix")
features <-c(features,jsfeatures)
log_features <- c("ns", "nd", "nf", "entropy", "exp", "rexp", "sexp", "ndev", "age", "nuc", "la", "ld", "lt")
log_features <- c(log_features,jsfeatures)


# statistical information related to projects
# make sure that, the order of projects in variable of "projects" is as same as the order of "statis_summary_js.csv"
{
fn_save_summary_statis <- "statis_summary_js.csv"
project_factors <- read.csv(fn_save_summary_statis)
selected_project_factors <- project_factors[factors_with_project]
# discretization of nummeric feature
selected_project_factors$stars <- factor(cut(selected_project_factors$stars, quantile(selected_project_factors$stars), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$fork <- factor(cut(selected_project_factors$fork, quantile(selected_project_factors$fork), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$branch <- factor(cut(selected_project_factors$branch, quantile(selected_project_factors$branch), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$change <- factor(cut(selected_project_factors$change, quantile(selected_project_factors$change), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$defective <- factor(cut(selected_project_factors$defective, quantile(selected_project_factors$defective), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$defratio <- factor(cut(selected_project_factors$defratio, quantile(selected_project_factors$defratio), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$file <- factor(cut(selected_project_factors$file, quantile(selected_project_factors$file), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$loc <- factor(cut(selected_project_factors$loc, quantile(selected_project_factors$loc), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$contributor <- factor(cut(selected_project_factors$contributor, quantile(selected_project_factors$contributor), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))

selected_project_factors$mediann <- factor(cut(selected_project_factors$mediann, quantile(selected_project_factors$mediann), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
selected_project_factors$meann <- factor(cut(selected_project_factors$meann, quantile(selected_project_factors$meann), include.lowest = TRUE), labels = c("Least", "Less", "More", "Most"))
}



# conbine feature value and project values into one set
combined_all_changes_factors <- NULL

for (project in js_projects){
   pro_index <- which(js_projects==project)
   this_project_factor <- selected_project_factors[pro_index,]
   change_data_url <- paste(c("preprocess/jsprojects-jshtml/", project, ".csv"), collapse="")
   changes <- read.csv(change_data_url)
   #changes <- changes[-which(changes$la+changes$ld > 10000 | changes$nf > 100), ]
   #changes <- changes[-which(changes$classification == "Merge"), ]
   #changes[which(changes$lt>0),]$la <- (changes[which(changes$lt>0),]$la/changes[which(changes$lt>0),]$lt)/changes[which(changes$lt>0),]$nf
   #changes[which(changes$lt>0),]$ld <- (changes[which(changes$lt>0),]$ld/changes[which(changes$lt>0),]$lt)/changes[which(changes$lt>0),]$nf
   #changes_log <- get_log_data(changes, log_features)
   selected_change_features <- changes[c(features,label)]
   num_changes <- nrow(selected_change_features)
   rep_factor_data <- this_project_factor[rep(rownames(this_project_factor),num_changes),]
   rownames(rep_factor_data) <- 1:nrow(rep_factor_data)
   combined_this_project_data <- cbind(selected_change_features, rep_factor_data)
   combined_all_changes_factors <- rbind(combined_all_changes_factors, combined_this_project_data)
}

{
temp_label <- combined_all_changes_factors[label][,1]
temp_label <- as.vector(temp_label)
temp_label[which(temp_label=="clean")] <- "FALSE"
temp_label[which(temp_label=="buggy")] <- "TRUE"
temp_label_factor <- factor(temp_label, order=TRUE, levels=c("FALSE", "TRUE"))
combined_all_changes_factors[label] <- temp_label_factor
}
# vcobj <- varclus(~., data = combined_all_changes_factors[,features], similarity = "spearman", trans = "abs")
# plot(vcobj)
# threshold <- 0.8
# abline(h = 1 - threshold, col = "red", lty = 2, lwd = 2)

# redun and colinar features: 'ns','entropy','ndev','nuc','ld','rexp')
#
# remove features in combined js projects (ns,entropy, ndev, nuc,ld,rexp)
combined_all_changes_factors$project <- as.factor(combined_all_changes_factors$project)
# remain features.
#nd+nf+exp+sexp+age+la+[lt]+is_fix + htmlcss + strict + bdom + so+ tc



mixed.effect.null <- glm(contains_bug ~ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc,
                        data = combined_all_changes_factors, family = "binomial")



mix.model <- glmer(contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+
   (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)+(1|file)+(1|loc)+(1|contributor)
   +(1|mediann)+(1|meann),
   data = combined_all_changes_factors, family = "binomial",
                       control=glmerControl(optimizer="optimx",
                                            optCtrl=list(method="nlminb")))

mix.model.r2GLMM <- r.squaredGLMM(mix.model)
print(mix.model.r2GLMM)


mixed.effect.null.r2GLMM <- r.squaredGLMM(mixed.effect.null)
print(mixed.effect.null.r2GLMM)


get_randomeff_models <- function(id) {

  random.eff.formula <- c()
  #factors <- c("stars","fork","branch","change","defective","defratio","file","loc","contributor","mediann","meann")
  random.eff.formula[[1]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)+(1|file)+(1|loc)+(1|contributor)+(1|mediann)+(1|meann)
  random.eff.formula[[2]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)+(1|file)+(1|loc)+(1|contributor)+(1|mediann)
  random.eff.formula[[3]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)+(1|file)+(1|loc)+(1|contributor)
  random.eff.formula[[4]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)+(1|file)+(1|loc)
  random.eff.formula[[5]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)+(1|file)
  random.eff.formula[[6]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)+(1|defratio)
  random.eff.formula[[7]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)+(1|defective)
  random.eff.formula[[8]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)+(1|change)
  random.eff.formula[[9]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)+(1|branch)
  random.eff.formula[[10]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)+(1|fork)
  random.eff.formula[[11]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc+ (1|stars)
  random.eff.formula[[12]] <- contains_bug ~ (0 + lt | project)+ nd+nf+exp+sexp+age+la+is_fix + htmlcss + strict + bdom + so+ tc


  tmp_mixed_model <- glmer(random.eff.formula[[id]],
                             data = combined_all_changes_factors, family = "binomial",
                             control=glmerControl(optimizer="optimx",
                                                  optCtrl=list(method="nlminb")))
  return(tmp_mixed_model)
}

randomeff_models <- list()

for (i in c(12)){
  randomeff_models[[i]] <- get_randomeff_models(i)
  print(paste("task-",i,"over!"))
}


anova_result <- anova(mix.model,
                      randomeff_models[[1]], randomeff_models[[2]], randomeff_models[[3]],
                      randomeff_models[[4]], randomeff_models[[5]], randomeff_models[[6]],
                      randomeff_models[[8]], randomeff_models[[9]],
                      randomeff_models[[10]], randomeff_models[[11]], randomeff_models[[12]],
                      mixed.effect.null)



summary_mixed_model <- summary(mix.model)
coefficients_mixed_model <- summary_mixed_model[["coefficients"]]
print(paste('summary_mixed_model coefficients',coefficients_mixed_model))

chisq_change_level <- Anova(mix.model, test = "Chisq")
print(paste('chisq_change_level ',chisq_change_level))
